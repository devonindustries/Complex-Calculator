# Complex Calculator
 A calculator for performing complex arithmetic. Contains one class called 'Complex', which takes two arguments primarily.

 To create a complex number, say 1+i, we would write Complex(1,1). Arithmetic with complex numbers in this module is defined in the usual way, so to add complex numbers, all we need to write is

 ```
Complex(1, 0) + Complex(0, 1)
```

Which would return `Complex(1, 1)`, or as a string, `'1+i'`.